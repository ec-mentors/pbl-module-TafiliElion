package pbl_module.conlang_creator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConlangCreatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
